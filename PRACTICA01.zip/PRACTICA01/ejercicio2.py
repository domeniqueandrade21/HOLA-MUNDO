a = 12
b = 5

suma = a + b
resta = a - b
multiplicacion = a * b
division = a / b  # resultado en float
division_entera = a // b
resto = a % b

print("Suma:", suma)
print("Resta:", resta)
print("Multiplicación:", multiplicacion)
print("División:", division)
print("División entera:", division_entera)
print("Resto:", resto)