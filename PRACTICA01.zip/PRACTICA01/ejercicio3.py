nombre_completo = "Domenique Andrade"
hobby = "tocar guitarra"

mensaje = f"{nombre_completo} disfruta de {hobby} en su tiempo libre."
print(mensaje)