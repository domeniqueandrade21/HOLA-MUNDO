frutas = ["manzana", "banana", "mango"]

for fruta in frutas:
    print(fruta)