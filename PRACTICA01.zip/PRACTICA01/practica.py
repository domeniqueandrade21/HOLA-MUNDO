nombre = "Domenique"
edad = 21
ciudad = "Quito"

print("Nombre:", nombre)
print("Edad:", edad)
print("Ciudad:", ciudad)