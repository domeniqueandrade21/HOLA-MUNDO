mascota = {
    "nombre": "Luna",
    "tipo": "perro",
    "edad": 3
}

print("Nombre:", mascota["nombre"])
print("Tipo:", mascota["tipo"])
print("Edad:", mascota["edad"])